"""
NEUROTRADER PRO V4.0
Estrategia integrada de 1 minuto para IQ Option.
"""
import time
import logging
import threading
import json as _json
import os as _os
from datetime import datetime, timedelta
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading as _threading

import numpy as np
import pandas as pd
import pytz

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

ecuador = pytz.timezone("America/Guayaquil")

DURACION_OPERACION = 1
MAX_OPS_POR_HORA_POR_ACTIVO = 8
MAX_CONCURRENT_TRADES = 2
PAUSA_ENTRE_LOTES = 5
PAUSA_CALIENTES = 0.5
MAX_SCAN_WORKERS = 10
MIN_SCORE_PARA_OPERAR = 80
UMBRAL_PRESENAL = 68
ADX_M5_MAX = 32
ADX_M1_SR_MAX = 30
ADX_M1_TL_MIN = 18
ADX_M1_TL_MAX = 35
MFM_UMBRAL_CALL = 0.45
MFM_UMBRAL_PUT = -0.45
EMA_RAPIDA = 8
EMA_LENTA = 21
BB_PERIODO = 20
BB_DESVIACION = 2
SCAN_LOTE_ACTIVOS = 10

ACTIVOS_NORMALES = [
    'EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'XAUUSD',
    'GBPJPY', 'EURJPY', 'USDCAD', 'NZDUSD', 'USDCHF',
]
ACTIVOS_OTC = [
    'EURUSD-OTC', 'GBPUSD-OTC', 'USDJPY-OTC', 'EURGBP-OTC', 'EURJPY-OTC',
    'GBPJPY-OTC', 'NZDUSD-OTC', 'USDCHF-OTC', 'AUDCAD-OTC', 'USDSGD-OTC',
]
ACTIVOS_OBJETIVO = ACTIVOS_NORMALES + ACTIVOS_OTC

LICENCIAS_FILE = "licencias.json"
_velas_cache = {}
_VELAS_CACHE_TTL = 4
_scan_lock = _threading.Lock()
_activos_exception = set()


def es_otc(asset: str) -> bool:
    return asset.upper().endswith('-OTC')


def _cargar_licencias() -> dict:
    if _os.path.exists(LICENCIAS_FILE):
        try:
            with open(LICENCIAS_FILE, 'r', encoding='utf-8') as f:
                return _json.load(f)
        except Exception:
            pass
    return {}


def validar_licencia(codigo: str, email: str = None) -> tuple:
    codigo = codigo.strip().upper() if codigo else ""
    if not codigo:
        return False, "Codigo de licencia requerido"
    licencias = _cargar_licencias()
    if not licencias:
        return False, "No hay licencias registradas. Contacte al administrador."
    if codigo not in licencias:
        return False, f"Codigo '{codigo}' no valido"
    lic = licencias[codigo]
    if not lic.get('active', True):
        return False, "Licencia desactivada. Contacte al administrador."
    expires = lic.get('expires')
    if expires:
        try:
            exp_date = datetime.fromisoformat(expires)
            if 'T' not in expires and ':' not in expires:
                exp_date = exp_date.replace(hour=23, minute=59, second=59)
            if datetime.now() > exp_date:
                return False, f"Licencia expirada el {expires[:10]}"
        except Exception:
            pass
    lic_email = lic.get('email', '').strip().lower()
    if lic_email and email and email.strip().lower() != lic_email:
        return False, "Este codigo no corresponde al correo ingresado"
    plan = lic.get('plan', '')
    plan_txt = {
        'semanal': 'Plan Semanal',
        'mensual': 'Plan Mensual',
        'vitalicio': 'Plan Vitalicio'
    }.get(plan, 'acceso completo')
    return True, f"Licencia valida — {plan_txt}"


def crear_licencia(codigo: str, descripcion: str = '', expires: str = None) -> bool:
    licencias = _cargar_licencias()
    licencias[codigo.strip().upper()] = {
        'active': True,
        'descripcion': descripcion,
        'expires': expires,
        'creado': datetime.now().isoformat()[:19],
    }
    try:
        with open(LICENCIAS_FILE, 'w', encoding='utf-8') as f:
            _json.dump(licencias, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False


class AdaptiveMemory:
    def __init__(self, ventana=25):
        self.ventana = ventana
        self.historial_asset = defaultdict(lambda: deque(maxlen=ventana))
        self.historial_estrategia = defaultdict(lambda: deque(maxlen=ventana))
        self.historial_combo = defaultdict(lambda: deque(maxlen=ventana))
        self.racha_asset = defaultdict(int)

    def registrar(self, asset, estrategia, gano, regimen='RANGE', direccion='CALL'):
        val = 1 if gano else 0
        self.historial_asset[asset].append(val)
        self.historial_estrategia[estrategia].append(val)
        self.historial_combo[f"{asset}::{estrategia}"].append(val)
        self.racha_asset[asset] = self.racha_asset[asset] + 1 if gano else self.racha_asset[asset] - 1

    def win_rate_asset(self, asset):
        h = self.historial_asset[asset]
        if len(h) < 3:
            return 0.70
        return sum(h) / len(h)

    def factor_confianza(self, asset, estrategia):
        wr_a = self.win_rate_asset(asset)
        h_e = self.historial_estrategia[estrategia]
        wr_e = sum(h_e) / len(h_e) if len(h_e) >= 3 else 0.70
        h_c = self.historial_combo[f"{asset}::{estrategia}"]
        wr_c = sum(h_c) / len(h_c) if len(h_c) >= 2 else 0.70
        return max(0.1, min(1.5, wr_a * 0.35 + wr_e * 0.30 + wr_c * 0.35))

    def resumen_aprendizaje(self):
        resumen = {}
        for asset, h in self.historial_asset.items():
            if len(h) >= 3:
                wr = sum(h) / len(h)
                resumen[asset] = {'win_rate': round(wr, 3), 'ops': len(h), 'racha': self.racha_asset.get(asset, 0)}
        return dict(sorted(resumen.items(), key=lambda x: -x[1]['win_rate']))


class BotState:
    def __init__(self):
        self.running = False
        self.logs = []
        self.trades = []
        self.active_trades = []
        self.saldo = 0.0
        self.saldo_inicial = 0.0
        self.api = None
        self.tipo_cuenta = "PRACTICE"
        self.monto = 1.0
        self.asset_ops_hist = defaultdict(list)
        self.stats = {
            'total': 0, 'ganadas': 0, 'perdidas': 0, 'devueltas': 0,
            'profit': 0.0,
            'por_estrategia': {
                'sr_rebote': {'total': 0, 'ganadas': 0},
                'tl_continuacion': {'total': 0, 'ganadas': 0},
                'ema_momentum': {'total': 0, 'ganadas': 0},
            }
        }
        self.ops_dia = 0
        self.max_ops_dia = None
        self.ops_dia_fecha = None
        self.bloqueo_asset_est = {}
        self.activos_disponibles = []
        self.señal_actual = None
        self.scan_progreso = 0
        self.scan_total = 0
        self.ia = AdaptiveMemory(ventana=25)
        self.regimenes = {}
        self._email = ""
        self._password = ""
        self.perdidas_consecutivas = 0
        self.pausa_hasta = None
        self._ultimo_refresh_activos = 0
        self._candidatos_cache = []
        self._cursor_activos = 0
        self._ultimo_ciclo_min = -1
        self._lista_caliente = {}
        self.tipo_operacion = 'binaria'
        self.scan_diagnostico = {}
        self.last_scan_detalle = ""
        self.presenales_activas = []

    @property
    def current_trade(self):
        return self.active_trades[0] if self.active_trades else None

    def add_log(self, msg, nivel="INFO"):
        ts = datetime.now(ecuador).strftime('%H:%M:%S')
        self.logs.append({"time": ts, "msg": msg, "nivel": nivel})
        if len(self.logs) > 500:
            self.logs = self.logs[-500:]

    def add_trade(self, trade):
        self.trades.append(trade)
        self.stats['total'] += 1
        est = trade.get('estrategia', 'sr_rebote')
        gano = trade['estado'] == 'GANADA'
        self.ia.registrar(trade['asset'], est, gano, regimen=trade.get('regimen', 'RANGE'), direccion=trade.get('direccion', 'CALL'))
        if est in self.stats['por_estrategia']:
            self.stats['por_estrategia'][est]['total'] += 1
            if gano:
                self.stats['por_estrategia'][est]['ganadas'] += 1
        if gano:
            self.stats['ganadas'] += 1
            self.stats['profit'] += trade.get('ganancia', 0)
            self.perdidas_consecutivas = 0
        elif trade['estado'] == 'PERDIDA':
            self.stats['perdidas'] += 1
            self.stats['profit'] -= trade['monto']
            self.perdidas_consecutivas += 1
            if self.perdidas_consecutivas >= 3:
                self.pausa_hasta = datetime.now(ecuador) + timedelta(minutes=3)
                self.add_log("Pausa protectora: 3 perdidas consecutivas. Capital fijo preservado.", "WARN")
        else:
            self.stats['devueltas'] += 1
        if len(self.trades) > 300:
            self.trades = self.trades[-300:]

    def puede_operar_asset(self, asset):
        ahora = datetime.now(ecuador)
        hace_una_hora = ahora - timedelta(hours=1)
        ops = [t for t in self.asset_ops_hist[asset] if t > hace_una_hora]
        self.asset_ops_hist[asset] = ops
        return len(ops) < MAX_OPS_POR_HORA_POR_ACTIVO

    def registrar_op(self, asset):
        self.asset_ops_hist[asset].append(datetime.now(ecuador))

    @property
    def win_rate(self):
        cerradas = self.stats['ganadas'] + self.stats['perdidas']
        return (self.stats['ganadas'] / cerradas * 100) if cerradas > 0 else 0.0


def _diag_scan(state, clave):
    try:
        with _scan_lock:
            state.scan_diagnostico[clave] = state.scan_diagnostico.get(clave, 0) + 1
    except Exception:
        pass


def obtener_activos_disponibles(api):
    try:
        disponibles = []
        detalle = api.get_binary_option_detail()
        for asset in ACTIVOS_OBJETIVO:
            info_asset = detalle.get(asset, {}) if detalle else {}
            for tipo in ['turbo', 'binary']:
                info = info_asset.get(tipo, {}) if isinstance(info_asset, dict) else {}
                if not isinstance(info, dict) or not info:
                    continue
                enabled = bool(info.get('enabled', info.get('is_active', True)))
                suspended = bool(info.get('is_suspended', info.get('suspended', False)))
                abierto = bool(info.get('open', info.get('is_open', True)))
                if enabled and abierto and not suspended:
                    disponibles.append(asset)
                    break
        return disponibles or ACTIVOS_OBJETIVO[:]
    except Exception as e:
        logger.error(f"Error activos: {e}")
        return ACTIVOS_OBJETIVO[:]


def is_asset_open(api, asset):
    try:
        detalle = api.get_binary_option_detail()
        info_asset = detalle.get(asset, {}) if detalle else {}
        for tipo in ['turbo', 'binary']:
            info = info_asset.get(tipo, {}) if isinstance(info_asset, dict) else {}
            if not isinstance(info, dict) or not info:
                continue
            enabled = bool(info.get('enabled', info.get('is_active', True)))
            suspended = bool(info.get('is_suspended', info.get('suspended', False)))
            abierto = bool(info.get('open', info.get('is_open', True)))
            if enabled and abierto and not suspended:
                return True
        return False
    except Exception:
        return False


def obtener_velas(api, asset, n=100, timeframe=60, forzar_fresco=False):
    ahora_ts = time.time()
    cache_key = (asset, timeframe)
    if not forzar_fresco:
        cached = _velas_cache.get(cache_key)
        ttl = _VELAS_CACHE_TTL if timeframe == 60 else 20
        if cached and (ahora_ts - cached[0]) < ttl:
            return cached[1]
    try:
        candles = api.get_candles(asset, timeframe, n, ahora_ts)
        if not candles or len(candles) < 30:
            return None
        df = pd.DataFrame(candles)
        for col in ['open', 'max', 'min', 'close', 'volume']:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        df.dropna(subset=['open', 'close', 'max', 'min'], inplace=True)
        if len(df) < 30:
            return None
        df.rename(columns={'max': 'high', 'min': 'low'}, inplace=True)
        df = df.reset_index(drop=True)
        _velas_cache[cache_key] = (ahora_ts, df)
        return df
    except Exception:
        return None


def calcular_indicadores(df):
    df = df.copy()
    c = df['close']
    h = df['high']
    l = df['low']
    o = df['open']
    v = df['volume'] if 'volume' in df.columns else pd.Series(1.0, index=df.index)
    for span in [EMA_RAPIDA, EMA_LENTA]:
        df[f'ema{span}'] = c.ewm(span=span, adjust=False).mean()
    sma = c.rolling(BB_PERIODO).mean()
    std = c.rolling(BB_PERIODO).std()
    df['bb_mid'] = sma
    df['bb_upper'] = sma + BB_DESVIACION * std
    df['bb_lower'] = sma - BB_DESVIACION * std
    tr = pd.concat([(h - l), (h - c.shift(1)).abs(), (l - c.shift(1)).abs()], axis=1).max(axis=1)
    df['atr'] = tr.ewm(alpha=1 / 14, adjust=False).mean()
    up_move = h.diff()
    down_move = -l.diff()
    plus_dm = pd.Series(np.where((up_move > down_move) & (up_move > 0), up_move, 0.0), index=df.index)
    minus_dm = pd.Series(np.where((down_move > up_move) & (down_move > 0), down_move, 0.0), index=df.index)
    atr_adx = tr.ewm(alpha=1 / 14, adjust=False).mean().replace(0, np.nan)
    plus_di = 100 * plus_dm.ewm(alpha=1 / 14, adjust=False).mean() / atr_adx
    minus_di = 100 * minus_dm.ewm(alpha=1 / 14, adjust=False).mean() / atr_adx
    dx = 100 * (plus_di - minus_di).abs() / ((plus_di + minus_di).replace(0, np.nan))
    df['adx14'] = dx.ewm(alpha=1 / 14, adjust=False).mean().fillna(0)
    df['plus_di'] = plus_di.fillna(0)
    df['minus_di'] = minus_di.fillna(0)
    df['mfm'] = (((c - l) - (h - c)) / (h - l + 1e-10)).clip(-1, 1)
    df['mfm14'] = df['mfm'].rolling(14, min_periods=1).mean()
    df['mfv'] = df['mfm'] * v
    df['adl'] = df['mfv'].cumsum()
    df['body'] = (c - o).abs()
    df['rango'] = h - l
    df['body_ratio'] = df['body'] / (df['rango'] + 1e-10)
    df['is_bull'] = c > o
    df['upper_wick'] = h - pd.concat([o, c], axis=1).max(axis=1)
    df['lower_wick'] = pd.concat([o, c], axis=1).min(axis=1) - l
    df['wick_ratio_lower'] = df['lower_wick'] / (df['rango'] + 1e-10)
    df['wick_ratio_upper'] = df['upper_wick'] / (df['rango'] + 1e-10)
    return df


def _adx_ok_m5(df_m5):
    if df_m5 is None or len(df_m5) < 30:
        return False, 99.0
    df5 = calcular_indicadores(df_m5)
    adx5 = float(df5.iloc[-1].get('adx14', 99))
    return adx5 <= ADX_M5_MAX, adx5


def _adl_subiendo(df, velas=5):
    s = df['adl'].tail(velas)
    if len(s) < 3:
        return False
    return float(s.iloc[-1]) > float(s.iloc[-2]) > float(s.iloc[-3]) or float(s.iloc[-1]) > float(s.min()) and float(s.iloc[-1]) > float(s.iloc[0])


def _adl_bajando(df, velas=5):
    s = df['adl'].tail(velas)
    if len(s) < 3:
        return False
    return float(s.iloc[-1]) < float(s.iloc[-2]) < float(s.iloc[-3]) or float(s.iloc[-1]) < float(s.max()) and float(s.iloc[-1]) < float(s.iloc[0])


def _ema_cruce_alcista(df):
    if len(df) < 3:
        return False
    p = df.iloc[-2]
    u = df.iloc[-1]
    return float(p[f'ema{EMA_RAPIDA}']) <= float(p[f'ema{EMA_LENTA}']) and float(u[f'ema{EMA_RAPIDA}']) > float(u[f'ema{EMA_LENTA}'])


def _ema_cruce_bajista(df):
    if len(df) < 3:
        return False
    p = df.iloc[-2]
    u = df.iloc[-1]
    return float(p[f'ema{EMA_RAPIDA}']) >= float(p[f'ema{EMA_LENTA}']) and float(u[f'ema{EMA_RAPIDA}']) < float(u[f'ema{EMA_LENTA}'])


def _emas_favorables_sr(df, direccion):
    """Para rebote S/R: acepta la señal si las EMAs no contradicen fuertemente
    la dirección. Permite operar en zonas de giro/consolidación donde las EMAs
    aún no han confirmado el cambio de dirección (que es cuando mejor rebota S/R)."""
    if len(df) < 4:
        return False
    u = df.iloc[-1]
    close = float(u['close'])
    atr = max(float(u.get('atr', 0)), close * 0.0001, 1e-10)
    e8_val = float(u[f'ema{EMA_RAPIDA}'])
    e21_val = float(u[f'ema{EMA_LENTA}'])
    e8_prev = float(df[f'ema{EMA_RAPIDA}'].iloc[-2])
    brecha = abs(e8_val - e21_val)

    if direccion == 'CALL':
        if _emas_arriba(df) or _ema_cruce_alcista(df):
            return True
        if brecha <= atr * 2.5:
            return True
        if close >= e21_val:
            return True
        descenso_e8 = e8_prev - e8_val
        if descenso_e8 < atr * 0.3:
            return True
        return False
    else:
        if _emas_abajo(df) or _ema_cruce_bajista(df):
            return True
        if brecha <= atr * 2.5:
            return True
        if close <= e21_val:
            return True
        subida_e8 = e8_val - e8_prev
        if subida_e8 < atr * 0.3:
            return True
        return False


def _emas_arriba(df, fuerte=False):
    if len(df) < 4:
        return False
    u = df.iloc[-1]
    e8 = df[f'ema{EMA_RAPIDA}']
    e21 = df[f'ema{EMA_LENTA}']
    pendiente = e8.iloc[-1] > e8.iloc[-2] and e21.iloc[-1] > e21.iloc[-2]
    if fuerte:
        pendiente = pendiente and e8.iloc[-2] > e8.iloc[-3] and e21.iloc[-2] > e21.iloc[-3]
    return pendiente and float(u['close']) > float(u[f'ema{EMA_RAPIDA}']) > float(u[f'ema{EMA_LENTA}'])


def _emas_abajo(df, fuerte=False):
    if len(df) < 4:
        return False
    u = df.iloc[-1]
    e8 = df[f'ema{EMA_RAPIDA}']
    e21 = df[f'ema{EMA_LENTA}']
    pendiente = e8.iloc[-1] < e8.iloc[-2] and e21.iloc[-1] < e21.iloc[-2]
    if fuerte:
        pendiente = pendiente and e8.iloc[-2] < e8.iloc[-3] and e21.iloc[-2] < e21.iloc[-3]
    return pendiente and float(u['close']) < float(u[f'ema{EMA_RAPIDA}']) < float(u[f'ema{EMA_LENTA}'])


def _pivotes(df, tipo='low', lookback=50, ancho=2):
    inicio = max(0, len(df) - lookback - 1)
    fin = len(df) - 1
    datos = df.iloc[inicio:fin]
    pivots = []
    for idx in range(ancho, len(datos) - ancho):
        row = datos.iloc[idx]
        win = datos.iloc[idx - ancho:idx + ancho + 1]
        real_idx = datos.index[idx]
        if tipo == 'low' and float(row['low']) <= float(win['low'].min()):
            pivots.append((real_idx, float(row['low'])))
        if tipo == 'high' and float(row['high']) >= float(win['high'].max()):
            pivots.append((real_idx, float(row['high'])))
    return pivots


def _validacion_m5_sr(df_m5, nivel, tipo, tolerancia):
    if df_m5 is None or len(df_m5) < 30:
        return False
    datos = df_m5.tail(40)
    if tipo == 'support':
        touches = datos[datos['low'] <= nivel + tolerancia]
        reactions = touches[touches['close'] > touches['open']]
    else:
        touches = datos[datos['high'] >= nivel - tolerancia]
        reactions = touches[touches['close'] < touches['open']]
    if len(touches) >= 1 and len(reactions) >= 1:
        return True
    if tipo == 'support':
        return abs(float(datos['low'].min()) - nivel) <= tolerancia * 2
    return abs(float(datos['high'].max()) - nivel) <= tolerancia * 2


def _zona_sr_fuerte(df, df_m5, direccion):
    if len(df) < 55:
        return None
    u = df.iloc[-1]
    atr = max(float(u.get('atr', 0)), float(df['close'].iloc[-1]) * 0.00015, 1e-8)
    tolerancia = atr * 0.9
    datos = df.tail(55).iloc[:-1]
    if direccion == 'CALL':
        pivots = _pivotes(df, 'low', 50)
        niveles = [p[1] for p in pivots] or [float(datos['low'].quantile(0.10))]
        actual = float(u['low'])
        candidatos = [n for n in niveles if abs(actual - n) <= tolerancia * 2.5]
        if not candidatos:
            return None
        nivel = min(candidatos, key=lambda x: abs(actual - x))
        touches_prev = datos[datos['low'] <= nivel + tolerancia]
        if len(touches_prev) < 2:
            return None
        if df_m5 is not None and not _validacion_m5_sr(df_m5, nivel, 'support', tolerancia * 2):
            return None
        return {'nivel': nivel, 'toques': len(touches_prev) + 1, 'tipo': 'Soporte fuerte M1/M5'}
    pivots = _pivotes(df, 'high', 50)
    niveles = [p[1] for p in pivots] or [float(datos['high'].quantile(0.90))]
    actual = float(u['high'])
    candidatos = [n for n in niveles if abs(actual - n) <= tolerancia * 2.5]
    if not candidatos:
        return None
    nivel = min(candidatos, key=lambda x: abs(actual - x))
    touches_prev = datos[datos['high'] >= nivel - tolerancia]
    if len(touches_prev) < 2:
        return None
    if df_m5 is not None and not _validacion_m5_sr(df_m5, nivel, 'resistance', tolerancia * 2):
        return None
    return {'nivel': nivel, 'toques': len(touches_prev) + 1, 'tipo': 'Resistencia fuerte M1/M5'}


def _linea_tendencia_valida(df, direccion):
    if len(df) < 50:
        return None
    u = df.iloc[-1]
    atr = max(float(u.get('atr', 0)), float(u['close']) * 0.00015, 1e-8)
    tolerancia = atr * 1.1
    tipo = 'low' if direccion == 'CALL' else 'high'
    pivots = _pivotes(df, tipo, 50)
    if len(pivots) < 2:
        return None
    pivots = pivots[-8:]
    actual_idx = df.index[-1]
    precio_actual = float(u['low'] if direccion == 'CALL' else u['high'])
    mejor = None
    for i in range(len(pivots) - 1):
        for j in range(i + 1, len(pivots)):
            x1, y1 = pivots[i]
            x2, y2 = pivots[j]
            if x2 == x1:
                continue
            slope = (y2 - y1) / (x2 - x1)
            if direccion == 'CALL' and slope <= 0:
                continue
            if direccion == 'PUT' and slope >= 0:
                continue
            angle = abs(np.degrees(np.arctan(slope / atr)))
            if angle < 20 or angle > 60:
                continue
            def line_at(x):
                return y1 + slope * (x - x1)
            touches_prev = 0
            for x, y in pivots:
                if abs(y - line_at(x)) <= tolerancia:
                    touches_prev += 1
            current_line = line_at(actual_idx)
            if abs(precio_actual - current_line) <= tolerancia * 1.4 and touches_prev >= 2:
                candidato = {'nivel': current_line, 'toques': touches_prev + 1, 'angulo': angle}
                if mejor is None or candidato['toques'] > mejor['toques']:
                    mejor = candidato
    return mejor


def _reaccion_call(u):
    cuerpo_alcista = bool(u.get('is_bull', False)) and float(u.get('body_ratio', 0)) >= 0.18
    rechazo = float(u.get('wick_ratio_lower', 0)) >= 0.35 and float(u.get('lower_wick', 0)) > float(u.get('body', 0)) * 1.5
    return cuerpo_alcista or rechazo


def _reaccion_put(u):
    cuerpo_bajista = not bool(u.get('is_bull', True)) and float(u.get('body_ratio', 0)) >= 0.18
    rechazo = float(u.get('wick_ratio_upper', 0)) >= 0.35 and float(u.get('upper_wick', 0)) > float(u.get('body', 0)) * 1.5
    return cuerpo_bajista or rechazo


def estrategia_sr_rebote(df, df_m5, asset):
    u = df.iloc[-1]
    adx1 = float(u.get('adx14', 99))
    mfm = float(u.get('mfm', 0))
    señales = []
    soporte = _zona_sr_fuerte(df, df_m5, 'CALL')
    if soporte and _reaccion_call(u) and _emas_favorables_sr(df, 'CALL') and mfm > MFM_UMBRAL_CALL and adx1 <= ADX_M1_SR_MAX:
        score = 82 + min(8, soporte['toques'])
        score += 5 if _ema_cruce_alcista(df) else (3 if _emas_arriba(df) else 0)
        score += 4 if _adl_subiendo(df) else 0
        ema_tag = "cruce EMA" if _ema_cruce_alcista(df) else ("EMA alcista" if _emas_arriba(df) else "EMA neutr")
        adl_tag = "+ADL" if _adl_subiendo(df) else ""
        señales.append({
            'direccion': 'CALL', 'estrategia': 'sr_rebote', 'score': min(score, 100),
            'detalle': f"Rebote CALL soporte, {soporte['toques']} toques, {ema_tag}{adl_tag}, ADX1={adx1:.1f}"
        })
    resistencia = _zona_sr_fuerte(df, df_m5, 'PUT')
    if resistencia and _reaccion_put(u) and _emas_favorables_sr(df, 'PUT') and mfm < MFM_UMBRAL_PUT and adx1 <= ADX_M1_SR_MAX:
        score = 82 + min(8, resistencia['toques'])
        score += 5 if _ema_cruce_bajista(df) else (3 if _emas_abajo(df) else 0)
        score += 4 if _adl_bajando(df) else 0
        ema_tag = "cruce EMA" if _ema_cruce_bajista(df) else ("EMA bajista" if _emas_abajo(df) else "EMA neutr")
        adl_tag = "+ADL" if _adl_bajando(df) else ""
        señales.append({
            'direccion': 'PUT', 'estrategia': 'sr_rebote', 'score': min(score, 100),
            'detalle': f"Rebote PUT resist, {resistencia['toques']} toques, {ema_tag}{adl_tag}, ADX1={adx1:.1f}"
        })
    return señales


def estrategia_ema_momentum(df, df_m5, asset):
    """Estrategia 3: Cruce EMA 8/21 confirmado con MFM y ADX en rango tendencial.
    Detecta arranques de momentum con confirmacion de flujo de dinero."""
    u = df.iloc[-1]
    adx1 = float(u.get('adx14', 0))
    mfm = float(u.get('mfm', 0))
    señales = []
    if not (ADX_M1_TL_MIN < adx1 <= ADX_M1_TL_MAX + 5):
        return señales
    if _ema_cruce_alcista(df) and mfm > MFM_UMBRAL_CALL and _adl_subiendo(df) and _reaccion_call(u):
        score = 82 + (4 if adx1 >= 22 else 0) + (3 if float(u.get('mfm14', 0)) > 0.25 else 0)
        señales.append({
            'direccion': 'CALL', 'estrategia': 'ema_momentum', 'score': min(score, 100),
            'detalle': f"EMA cross CALL, MFM={mfm:.3f}, ADX1={adx1:.1f}, ADL↑"
        })
    if _ema_cruce_bajista(df) and mfm < MFM_UMBRAL_PUT and _adl_bajando(df) and _reaccion_put(u):
        score = 82 + (4 if adx1 >= 22 else 0) + (3 if float(u.get('mfm14', 0)) < -0.25 else 0)
        señales.append({
            'direccion': 'PUT', 'estrategia': 'ema_momentum', 'score': min(score, 100),
            'detalle': f"EMA cross PUT, MFM={mfm:.3f}, ADX1={adx1:.1f}, ADL↓"
        })
    return señales


def estrategia_tl_continuacion(df, df_m5, asset):
    u = df.iloc[-1]
    adx1 = float(u.get('adx14', 0))
    señales = []
    tl_call = _linea_tendencia_valida(df, 'CALL')
    if tl_call and _reaccion_call(u) and _emas_arriba(df, fuerte=True) and _adl_subiendo(df) and float(u.get('mfm', 0)) > MFM_UMBRAL_CALL and ADX_M1_TL_MIN < adx1 <= ADX_M1_TL_MAX:
        score = 84 + min(8, tl_call['toques']) + (4 if 30 <= tl_call['angulo'] <= 55 else 0)
        señales.append({
            'direccion': 'CALL', 'estrategia': 'tl_continuacion', 'score': min(score, 100),
            'detalle': f"Continuacion CALL en TL alcista {tl_call['angulo']:.1f}°, {tl_call['toques']} toques, ADX1={adx1:.1f}"
        })
    tl_put = _linea_tendencia_valida(df, 'PUT')
    if tl_put and _reaccion_put(u) and _emas_abajo(df, fuerte=True) and _adl_bajando(df) and float(u.get('mfm', 0)) < MFM_UMBRAL_PUT and ADX_M1_TL_MIN < adx1 <= ADX_M1_TL_MAX:
        score = 84 + min(8, tl_put['toques']) + (4 if 30 <= tl_put['angulo'] <= 55 else 0)
        señales.append({
            'direccion': 'PUT', 'estrategia': 'tl_continuacion', 'score': min(score, 100),
            'detalle': f"Continuacion PUT en TL bajista {tl_put['angulo']:.1f}°, {tl_put['toques']} toques, ADX1={adx1:.1f}"
        })
    return señales


def _registrar_presenal_v4(df, df_m5, asset, state):
    try:
        u = df.iloc[-1]
        adx1 = float(u.get('adx14', 99))
        mfm = float(u.get('mfm', 0))
        presenales = []
        soporte = _zona_sr_fuerte(df, df_m5, 'CALL')
        if soporte and adx1 <= ADX_M1_SR_MAX:
            score = 60 + min(10, soporte['toques'])
            score += 8 if mfm > 0.45 else 0
            score += 6 if _ema_cruce_alcista(df) else (4 if _emas_arriba(df) else (2 if _emas_favorables_sr(df, 'CALL') else 0))
            score += 6 if _adl_subiendo(df) else 0
            score += 5 if _reaccion_call(u) else 0
            presenales.append(('CALL', 'sr_rebote', score))
        resistencia = _zona_sr_fuerte(df, df_m5, 'PUT')
        if resistencia and adx1 <= ADX_M1_SR_MAX:
            score = 60 + min(10, resistencia['toques'])
            score += 8 if mfm < -0.45 else 0
            score += 6 if _ema_cruce_bajista(df) else (4 if _emas_abajo(df) else (2 if _emas_favorables_sr(df, 'PUT') else 0))
            score += 6 if _adl_bajando(df) else 0
            score += 5 if _reaccion_put(u) else 0
            presenales.append(('PUT', 'sr_rebote', score))
        tl_call = _linea_tendencia_valida(df, 'CALL')
        if tl_call and ADX_M1_TL_MIN < adx1 <= ADX_M1_TL_MAX:
            score = 60 + min(10, tl_call['toques'])
            score += 7 if 30 <= tl_call['angulo'] <= 55 else 0
            score += 7 if mfm > 0.45 else 0
            score += 6 if _emas_arriba(df) else 0
            score += 5 if _adl_subiendo(df) else 0
            presenales.append(('CALL', 'tl_continuacion', score))
        tl_put = _linea_tendencia_valida(df, 'PUT')
        if tl_put and ADX_M1_TL_MIN < adx1 <= ADX_M1_TL_MAX:
            score = 60 + min(10, tl_put['toques'])
            score += 7 if 30 <= tl_put['angulo'] <= 55 else 0
            score += 7 if mfm < -0.45 else 0
            score += 6 if _emas_abajo(df) else 0
            score += 5 if _adl_bajando(df) else 0
            presenales.append(('PUT', 'tl_continuacion', score))
        u2 = df.iloc[-1]
        if ADX_M1_TL_MIN < adx1 <= ADX_M1_TL_MAX + 5:
            if _ema_cruce_alcista(df):
                score = 65 + (8 if mfm > 0.45 else (4 if mfm > 0.2 else 0))
                score += 5 if _adl_subiendo(df) else 0
                score += 5 if _reaccion_call(u2) else 0
                presenales.append(('CALL', 'ema_momentum', score))
            if _ema_cruce_bajista(df):
                score = 65 + (8 if mfm < -0.45 else (4 if mfm < -0.2 else 0))
                score += 5 if _adl_bajando(df) else 0
                score += 5 if _reaccion_put(u2) else 0
                presenales.append(('PUT', 'ema_momentum', score))
        if not presenales:
            return None
        direccion, estrategia, score = max(presenales, key=lambda x: x[2])
        if score >= UMBRAL_PRESENAL:
            with _scan_lock:
                state._lista_caliente[asset] = (time.time(), score, direccion, estrategia)
            return {'asset': asset, 'direccion': direccion, 'estrategia': estrategia, 'score': score}
        return None
    except Exception:
        return None


ESTRATEGIA_NOMBRES = {
    'sr_rebote': 'V4 Rebote S/R fuerte',
    'tl_continuacion': 'V4 Continuacion TL valida',
    'ema_momentum': 'V4 Momentum EMA 8/21',
}


def analizar_activo(api, asset, state):
    try:
        if asset not in ACTIVOS_OBJETIVO or not state.puede_operar_asset(asset):
            _diag_scan(state, 'bloqueado')
            return None
        df1_raw = obtener_velas(api, asset, n=120, timeframe=60)
        df5_raw = obtener_velas(api, asset, n=80, timeframe=300)
        if df1_raw is None or len(df1_raw) < 55:
            _diag_scan(state, 'sin_velas_m1')
            return None
        df1 = calcular_indicadores(df1_raw)
        df5 = calcular_indicadores(df5_raw) if df5_raw is not None else None
        ok_m5, adx5 = _adx_ok_m5(df5_raw)
        state.regimenes[asset] = f"ADX5 {adx5:.1f}"
        if df5_raw is not None and not ok_m5:
            _diag_scan(state, 'adx_m5_alto')
            state.add_log(f"[{asset}] ADX-M5={adx5:.1f} > {ADX_M5_MAX} → descartado", "DEBUG")
            return None
        if df5_raw is None:
            adx5 = 0.0
            state.add_log(f"[{asset}] Sin datos M5, analizando solo en M1", "DEBUG")
        presenal = _registrar_presenal_v4(df1, df5_raw, asset, state)
        if presenal:
            _diag_scan(state, 'presenal')
        señales = []
        señales.extend(estrategia_sr_rebote(df1, df5_raw, asset))
        señales.extend(estrategia_tl_continuacion(df1, df5_raw, asset))
        señales.extend(estrategia_ema_momentum(df1, df5_raw, asset))
        if not señales:
            u = df1.iloc[-1]
            adx1 = float(u.get('adx14', 99))
            mfm = float(u.get('mfm', 0))
            zona_c = _zona_sr_fuerte(df1, df5_raw, 'CALL')
            zona_p = _zona_sr_fuerte(df1, df5_raw, 'PUT')
            motivos = []
            if not zona_c and not zona_p:
                motivos.append("sin zona S/R valida")
            else:
                if zona_c and not _reaccion_call(u):
                    motivos.append("sin reaccion alcista")
                if zona_p and not _reaccion_put(u):
                    motivos.append("sin reaccion bajista")
                if not (_adl_subiendo(df1) or _adl_bajando(df1)):
                    motivos.append("ADL neutro")
                if abs(mfm) < MFM_UMBRAL_CALL:
                    motivos.append(f"MFM={mfm:.3f} (min={MFM_UMBRAL_CALL})")
                if adx1 > ADX_M1_SR_MAX:
                    motivos.append(f"ADX1={adx1:.1f} (max={ADX_M1_SR_MAX})")
                if not (_emas_favorables_sr(df1, 'CALL') or _emas_favorables_sr(df1, 'PUT')):
                    u2 = df1.iloc[-1]
                    e8v = float(u2.get(f'ema{EMA_RAPIDA}', 0))
                    e21v = float(u2.get(f'ema{EMA_LENTA}', 0))
                    motivos.append(f"EMAs bloqueadas (EMA8={e8v:.5f} EMA21={e21v:.5f})")
            razon = ", ".join(motivos) if motivos else "condiciones no alineadas"
            state.add_log(f"[{asset}] sin setup — {razon}", "DEBUG")
            _diag_scan(state, 'sin_setup_completo')
            return None
        mejor = max(señales, key=lambda x: x['score'])
        if mejor['score'] >= UMBRAL_PRESENAL:
            with _scan_lock:
                state._lista_caliente[asset] = (time.time(), mejor['score'])
        if mejor['score'] < MIN_SCORE_PARA_OPERAR:
            _diag_scan(state, 'score_bajo')
            return None
        confianza = state.ia.factor_confianza(asset, mejor['estrategia'])
        u = df1.iloc[-1]
        _diag_scan(state, 'senal_final')
        return {
            'asset': asset,
            'direccion': mejor['direccion'],
            'estrategia': mejor['estrategia'],
            'score': mejor['score'],
            'fuerza': mejor['score'],
            'sostenibilidad': mejor['score'],
            'nombre_estrategia': ESTRATEGIA_NOMBRES.get(mejor['estrategia'], mejor['estrategia']),
            'regimen': f"ADX5={adx5:.1f}",
            'confianza_ia': round(confianza * 100, 1),
            'filtro_calidad': mejor['detalle'],
            'mfm': round(float(u.get('mfm', 0)), 3),
            'mfm14': round(float(u.get('mfm14', 0)), 3),
            'adx1': round(float(u.get('adx14', 0)), 1),
            'adx5': round(adx5, 1),
            'duracion': DURACION_OPERACION,
            'n_estrategias': 1,
            'es_volatil': False,
        }
    except Exception as e:
        _diag_scan(state, 'error')
        state.add_log(f"Error analizando {asset}: {e}", "WARN")
        return None


def ejecutar_trade(api, asset, direccion, monto, estrategia, state, duracion=1):
    if asset in _activos_exception:
        state.add_log(f"{asset} bloqueado por fallo previo", "WARN")
        return False
    if len(state.active_trades) >= MAX_CONCURRENT_TRADES:
        return False
    if any(t['asset'] == asset for t in state.active_trades):
        return False
    opcion = "call" if direccion == "CALL" else "put"
    monto_real = round(float(monto), 2)
    try:
        tipo_op = getattr(state, 'tipo_operacion', 'binaria')
        if tipo_op == 'digital':
            success, order_id = api.buy_digital_spot(asset, monto_real, opcion, duracion)
        else:
            success, order_id = api.buy(monto_real, asset, opcion, duracion)
        if success:
            entrada = datetime.now(ecuador)
            trade = {
                'asset': asset,
                'direccion': direccion,
                'monto': monto_real,
                'entrada': entrada.strftime("%H:%M:%S"),
                'vencimiento': (entrada + timedelta(minutes=duracion)).strftime("%H:%M:%S"),
                'order_id': order_id,
                'estado': 'PENDIENTE',
                'estrategia': estrategia,
                'nombre_estrategia': ESTRATEGIA_NOMBRES.get(estrategia, estrategia),
                'ganancia': 0.0,
                'fecha': entrada.strftime("%d/%m %H:%M"),
                'regimen': state.regimenes.get(asset, '?'),
                '_ts_creado': time.time(),
                '_duracion': duracion,
            }
            state.active_trades.append(trade)
            state.registrar_op(asset)
            state.ops_dia += 1
            state.add_log(
                f"OPERACION [1MIN]: {asset} {direccion} ${monto_real:.2f} | {ESTRATEGIA_NOMBRES.get(estrategia, estrategia)} | ID:{order_id}",
                "TRADE"
            )
            return True
        msg = str(order_id) if order_id else "error"
        if "time" in msg.lower() or "purchasing" in msg.lower():
            state.add_log(f"{asset}: ventana vencida, operacion descartada", "WARN")
        else:
            state.add_log(f"Error al operar {asset}: {msg}", "ERROR")
        return False
    except Exception as e:
        state.add_log(f"Excepcion en trade ({asset}): {e} — activo omitido", "ERROR")
        _activos_exception.add(asset)
        return False


def verificar_resultado_trade(api, state, trade=None):
    if trade is None:
        trade = state.current_trade
    if trade is None or trade not in state.active_trades:
        return False
    try:
        ahora = datetime.now(ecuador)
        ts_creado = trade.get('_ts_creado', time.time() - 120)
        duracion_trade = trade.get('_duracion', DURACION_OPERACION)
        timeout_seg = duracion_trade * 60 + 30
        if time.time() - ts_creado > timeout_seg:
            trade['estado'] = 'DEVUELTA'
            trade['ganancia'] = 0.0
            state.add_trade(trade)
            if trade in state.active_trades:
                state.active_trades.remove(trade)
            state.add_log(f"Trade {trade['asset']} timeout → DEVUELTA", "WARN")
            return True
        venc_time = datetime.strptime(trade['vencimiento'], "%H:%M:%S").time()
        venc_dt = datetime.combine(ahora.date(), venc_time)
        if venc_dt.replace(tzinfo=None) < ahora.replace(tzinfo=None):
            venc_dt += timedelta(days=1)
        if ahora.replace(tzinfo=None) < venc_dt.replace(tzinfo=None) - timedelta(seconds=2):
            return False
        resultado = api.check_win_v4(trade['order_id'])
        if resultado is None:
            return False
        if isinstance(resultado, (list, tuple)) and len(resultado) >= 2:
            estado, ganancia = resultado[0], float(resultado[1])
        elif isinstance(resultado, str):
            estado, ganancia = resultado, 0.0
        else:
            estado, ganancia = str(resultado), 0.0
        if estado in ('win', 'Win', 'WIN'):
            trade['estado'] = 'GANADA'
            trade['ganancia'] = ganancia
            state.saldo += ganancia
            state.perdidas_consecutivas = 0
            state.add_log(f"GANADA: {trade['asset']} {trade['direccion']} +${ganancia:.2f} [1MIN]", "WIN")
        elif estado in ('loose', 'loss', 'Loose', 'LOSE', 'Loss'):
            trade['estado'] = 'PERDIDA'
            trade['ganancia'] = -trade['monto']
            state.saldo -= trade['monto']
            clave = (trade['asset'], trade.get('estrategia', ''))
            entrada_bloqueo = state.bloqueo_asset_est.get(clave, {'racha': 0, 'bloqueado_hasta': None})
            entrada_bloqueo['racha'] = entrada_bloqueo.get('racha', 0) + 1
            if entrada_bloqueo['racha'] >= 2:
                entrada_bloqueo['bloqueado_hasta'] = datetime.now(ecuador) + timedelta(minutes=30)
                state.add_log(f"{trade['asset']} bloqueado 30m por 2 perdidas consecutivas con la misma señal", "WARN")
            state.bloqueo_asset_est[clave] = entrada_bloqueo
            state.add_log(f"PERDIDA: {trade['asset']} {trade['direccion']} -${trade['monto']:.2f} [1MIN]", "LOSS")
        else:
            trade['estado'] = 'DEVUELTA'
            trade['ganancia'] = 0.0
            state.add_log(f"DEVUELTA: {trade['asset']} — {estado}", "INFO")
        state.add_trade(trade)
        if trade in state.active_trades:
            state.active_trades.remove(trade)
        return True
    except Exception as e:
        state.add_log(f"Error verificando resultado: {e}", "WARN")
        return False


def _hilo_verificar_resultado(api, state, trade=None):
    if trade is None:
        trade = state.current_trade
    if not trade:
        return
    duracion_min = trade.get('_duracion', DURACION_OPERACION)
    max_espera = duracion_min * 65 + 30
    inicio = time.time()
    while state.running and trade in state.active_trades and (time.time() - inicio) < max_espera:
        try:
            if verificar_resultado_trade(api, state, trade):
                return
        except Exception as e:
            state.add_log(f"Verificador resultado: {e}", "WARN")
        time.sleep(1.2)
    if trade in state.active_trades:
        trade['estado'] = 'DEVUELTA'
        trade['ganancia'] = 0.0
        state.add_trade(trade)
        state.active_trades.remove(trade)
        state.add_log(f"Trade {trade['asset']} liberado por timeout", "WARN")


def intentar_reconexion(state):
    try:
        if not state._email or not state._password:
            return False
        from iqoptionapi.stable_api import IQ_Option
        api_nueva = IQ_Option(state._email, state._password)
        check, reason = api_nueva.connect()
        if check:
            state.api = api_nueva
            state.add_log("Reconexion exitosa", "INFO")
            return True
        state.add_log(f"Reconexion fallida: {reason}", "WARN")
        return False
    except Exception as e:
        state.add_log(f"Error en reconexion: {e}", "ERROR")
        return False


def _analizar_wrapper(args):
    api, asset, state, progreso_ref = args
    try:
        resultado = analizar_activo(api, asset, state)
        with _scan_lock:
            progreso_ref[0] += 1
            state.scan_progreso = progreso_ref[0]
        return resultado
    except Exception:
        with _scan_lock:
            progreso_ref[0] += 1
            state.scan_progreso = progreso_ref[0]
        return None


def _refresh_activos_si_necesario(api, state):
    ahora_ts = time.time()
    if not state.activos_disponibles or (ahora_ts - state._ultimo_refresh_activos) > 900:
        activos_nuevos = obtener_activos_disponibles(api)
        if activos_nuevos:
            state.activos_disponibles = activos_nuevos
            state._ultimo_refresh_activos = ahora_ts
            state.add_log(f"Activos IQ Option disponibles: {len(activos_nuevos)} — {', '.join(activos_nuevos[:10])}", "INFO")


def scan_siguiente_lote(api, state):
    _refresh_activos_si_necesario(api, state)
    activos = state.activos_disponibles or ACTIVOS_OBJETIVO
    candidatos = [a for a in activos if state.puede_operar_asset(a) and a not in _activos_exception]
    if not candidatos:
        state.last_scan_detalle = "Sin candidatos: activos bloqueados/no disponibles"
        state.add_log("Scanner V4.0: sin candidatos operables", "WARN")
        return
    total = len(candidatos)
    state.scan_total = min(SCAN_LOTE_ACTIVOS, total)
    state.scan_progreso = 0
    with _scan_lock:
        state.scan_diagnostico = {}
    inicio = state._cursor_activos % total
    lote = []
    for i in range(min(SCAN_LOTE_ACTIVOS, total)):
        lote.append(candidatos[(inicio + i) % total])
    state._cursor_activos = (inicio + len(lote)) % total
    progreso_ref = [0]
    args_list = [(api, a, state, progreso_ref) for a in lote]
    nuevos = []
    with ThreadPoolExecutor(max_workers=min(MAX_SCAN_WORKERS, len(lote))) as executor:
        futures = [executor.submit(_analizar_wrapper, args) for args in args_list]
        for future in as_completed(futures):
            resultado = future.result()
            if resultado:
                nuevos.append(resultado)
    with _scan_lock:
        state._candidatos_cache.extend(nuevos)
        state._candidatos_cache.sort(key=lambda x: x['score'], reverse=True)
        state._candidatos_cache = state._candidatos_cache[:20]
        ahora = time.time()
        pres = []
        for a, dato in state._lista_caliente.items():
            if ahora - dato[0] < 60:
                pres.append({'asset': a, 'score': dato[1], 'direccion': dato[2] if len(dato) > 2 else '?', 'estrategia': dato[3] if len(dato) > 3 else 'V4'})
        pres.sort(key=lambda x: x['score'], reverse=True)
        state.presenales_activas = pres[:10]
        diag = dict(state.scan_diagnostico)
    orden = ['sin_velas_m1', 'adx_m5_alto', 'sin_setup_completo', 'presenal', 'score_bajo', 'senal_final', 'bloqueado', 'error']
    detalle = ", ".join(f"{k}={diag.get(k, 0)}" for k in orden if diag.get(k, 0))
    if not detalle:
        detalle = "sin descartes registrados"
    state.last_scan_detalle = detalle
    if nuevos:
        mejor = max(nuevos, key=lambda x: x['score'])
        state.add_log(f"Scan {len(lote)} activos → {len(nuevos)} señal(es) | calientes={len(state.presenales_activas)} | Mejor: {mejor['asset']} {mejor['direccion']} score={mejor['score']} | {mejor['filtro_calidad']}", "INFO")
    else:
        state.add_log(f"Scan {len(lote)} activos → sin señal V4.0 valida | calientes={len(state.presenales_activas)} | {detalle}", "INFO")


def _rechequear_calientes(api, state):
    with _scan_lock:
        ahora = time.time()
        calientes = [a for a, dato in state._lista_caliente.items() if a not in _activos_exception and ahora - dato[0] < 60]
        state._lista_caliente = {a: dato for a, dato in state._lista_caliente.items() if ahora - dato[0] < 60}
    if not calientes:
        return
    hot_args = [(api, a, state, [0]) for a in calientes[:SCAN_LOTE_ACTIVOS]]
    nuevos = []
    with ThreadPoolExecutor(max_workers=min(MAX_SCAN_WORKERS, len(hot_args))) as executor:
        futures = [executor.submit(_analizar_wrapper, args) for args in hot_args]
        for future in as_completed(futures):
            r = future.result()
            if r:
                nuevos.append(r)
    if nuevos:
        with _scan_lock:
            state._candidatos_cache.extend(nuevos)
            state._candidatos_cache.sort(key=lambda x: x['score'], reverse=True)
            state._candidatos_cache = state._candidatos_cache[:20]
            ahora = time.time()
            state.presenales_activas = [
                {'asset': a, 'score': dato[1], 'direccion': dato[2] if len(dato) > 2 else '?', 'estrategia': dato[3] if len(dato) > 3 else 'V4'}
                for a, dato in state._lista_caliente.items()
                if ahora - dato[0] < 60
            ][:10]
        mejor = max(nuevos, key=lambda x: x['score'])
        state.add_log(f"Pre-señal confirmada → {mejor['asset']} {mejor['direccion']} score={mejor['score']}", "SIGNAL")


def _hilo_scanner(api, state):
    while state.running:
        try:
            if not api or not state.running:
                time.sleep(1)
                continue
            if not state.activos_disponibles:
                _refresh_activos_si_necesario(api, state)
            scan_siguiente_lote(api, state)
            elapsed = 0
            while elapsed < PAUSA_ENTRE_LOTES and state.running:
                _rechequear_calientes(api, state)
                time.sleep(PAUSA_CALIENTES)
                elapsed += PAUSA_CALIENTES
        except Exception as e:
            state.add_log(f"Error en scanner: {e}", "ERROR")
            time.sleep(3)


def _verificar_senal_fresca(api, señal, state):
    try:
        reevaluada = analizar_activo(api, señal['asset'], state)
        if not reevaluada:
            return False
        misma_dir = reevaluada['direccion'] == señal['direccion']
        suficiente = reevaluada['score'] >= MIN_SCORE_PARA_OPERAR
        if misma_dir and suficiente:
            señal.update(reevaluada)
            return True
        return False
    except Exception:
        return False


def bot_engine(state):
    state.add_log(f"NeuroTrader Pro V4.0 — estrategia 1MIN | MFM>={MFM_UMBRAL_CALL} | ADX-M5<={ADX_M5_MAX} | ADX-M1<={ADX_M1_SR_MAX} | capital fijo", "INFO")
    state.add_log(f"Escaneo: {SCAN_LOTE_ACTIVOS} activos c/5s | Max ops simultaneas: {MAX_CONCURRENT_TRADES} | Score min: {MIN_SCORE_PARA_OPERAR}", "INFO")
    ultimo_minuto_operado = -1
    intentos_reconexion = 0
    max_intentos_reconexion = 5
    ultimo_log_min = -1
    hilo_scan = _threading.Thread(target=_hilo_scanner, args=(state.api, state), daemon=True, name="neuro-scanner-v4")
    hilo_scan.start()
    state.add_log("Scanner V4.0 iniciado", "INFO")

    def _disparar_señal(señal):
        if any(t['asset'] == señal['asset'] for t in state.active_trades):
            return False
        if len(state.active_trades) >= MAX_CONCURRENT_TRADES:
            return False
        ahora_ent = datetime.now(ecuador)
        tipo_tag = " [DIGITAL]" if getattr(state, 'tipo_operacion', 'binaria') == 'digital' else ""
        state.add_log(
            f"ENTRADA{tipo_tag} [1MIN] s{ahora_ent.second} — {señal['asset']} {señal['direccion']} | Score:{señal['score']} | {señal['filtro_calidad']}",
            "SIGNAL"
        )
        ok = ejecutar_trade(state.api, señal['asset'], señal['direccion'], state.monto, señal['estrategia'], state, duracion=señal.get('duracion', DURACION_OPERACION))
        if ok:
            nuevo_trade = state.active_trades[-1] if state.active_trades else None
            hilo_v = _threading.Thread(target=_hilo_verificar_resultado, args=(state.api, state, nuevo_trade), daemon=True, name=f"verificador-{señal['asset']}")
            hilo_v.start()
        return ok

    while state.running:
        try:
            if not state.api:
                time.sleep(0.5)
                continue
            try:
                conectado = state.api.check_connect()
            except Exception:
                conectado = False
            if not conectado:
                intentos_reconexion += 1
                state.add_log(f"Conexion perdida. Intento {intentos_reconexion}/{max_intentos_reconexion}...", "WARN")
                if intentos_reconexion <= max_intentos_reconexion:
                    time.sleep(3)
                    if intentar_reconexion(state):
                        intentos_reconexion = 0
                    continue
                state.add_log("No se pudo reconectar. Deteniendo bot.", "ERROR")
                state.running = False
                break
            intentos_reconexion = 0
            ahora = datetime.now(ecuador)
            segundo = ahora.second
            minuto_actual = ahora.minute
            if 2 <= segundo <= 4 and minuto_actual != state._ultimo_ciclo_min:
                with _scan_lock:
                    state._candidatos_cache = []
                state._ultimo_ciclo_min = minuto_actual
                ts_ahora = time.time()
                claves_exp = [k for k, (ts, _) in list(_velas_cache.items()) if ts_ahora - ts > 120]
                for k in claves_exp:
                    _velas_cache.pop(k, None)
                state.add_log(f"Min {minuto_actual:02d} — ciclo nuevo | {len(state.activos_disponibles or ACTIVOS_OBJETIVO)} activos IQ Option", "INFO")
            if state.pausa_hasta:
                if datetime.now(ecuador) < state.pausa_hasta:
                    time.sleep(1)
                    continue
                state.pausa_hasta = None
                state.perdidas_consecutivas = 0
                state.add_log("Pausa protectora terminada. Operaciones reanudadas.", "INFO")
            if not state.activos_disponibles:
                time.sleep(0.5)
                continue
            en_ventana_entrada = segundo >= 59 or segundo <= 1
            if minuto_actual != ultimo_minuto_operado and en_ventana_entrada and len(state.active_trades) < MAX_CONCURRENT_TRADES:
                ultimo_minuto_operado = minuto_actual
                with _scan_lock:
                    cache_snap = list(state._candidatos_cache)
                if cache_snap:
                    top = sorted(cache_snap, key=lambda x: x['score'], reverse=True)
                    disparadas = 0
                    capacidad = MAX_CONCURRENT_TRADES - len(state.active_trades)
                    for candidato in top[:5]:
                        if candidato['score'] < MIN_SCORE_PARA_OPERAR or disparadas >= capacidad:
                            break
                        if _verificar_senal_fresca(state.api, candidato, state):
                            state.señal_actual = candidato
                            if _disparar_señal(candidato):
                                disparadas += 1
                    if disparadas == 0 and minuto_actual != ultimo_log_min:
                        state.señal_actual = None
                        top_s = top[0]['score'] if top else 0
                        top_a = top[0]['asset'] if top else '-'
                        state.add_log(f"Min {minuto_actual:02d} — score max={top_s} ({top_a}) — sin confirmacion fresca", "WARN")
                else:
                    if minuto_actual != ultimo_log_min:
                        state.señal_actual = None
                        state.add_log(f"Min {minuto_actual:02d} — cache vacio, esperando escaneo V4.0", "INFO")
                ultimo_log_min = minuto_actual
            time.sleep(0.1)
        except Exception as e:
            state.add_log(f"Error en motor: {e}", "ERROR")
            time.sleep(1)
